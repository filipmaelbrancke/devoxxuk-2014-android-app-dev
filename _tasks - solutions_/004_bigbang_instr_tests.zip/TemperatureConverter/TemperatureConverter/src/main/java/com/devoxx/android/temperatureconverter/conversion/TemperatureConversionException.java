package com.devoxx.android.temperatureconverter.conversion;


public class TemperatureConversionException extends RuntimeException {

    public TemperatureConversionException(final String message) {
        super(message);
    }
}
