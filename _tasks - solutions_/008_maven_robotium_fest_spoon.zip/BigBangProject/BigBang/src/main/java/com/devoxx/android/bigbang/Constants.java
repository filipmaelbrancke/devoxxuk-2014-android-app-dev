package com.devoxx.android.bigbang;

/**
 * Constants.
 */
public class Constants {

    public static final String API_KEY = "keyf6ee113xlu93nrinuod9zu8k";
    public static final String SECRET = "secretchae3ixvauwvhybx0bt85hef";
}
